# Output Spec — Tripo image->3D input

These override the style guidance. Follow exactly.

## Subject & framing
- Exactly ONE subject, centred, whole in frame with an even margin. Nothing
  cropped, nothing touching an edge.
- Clean three-quarter hero view that reads the full silhouette.
- Neutral, near-symmetrical standing pose facing the viewer. Arms and legs held
  CLEAR of the torso so reconstruction does not fuse limbs into the body.
- No action pose, motion blur, or foreshortening.

## Background
- Flat, solid, plain — pure white or neutral mid-grey, nothing else.
- No ground, cast shadow, terrain, sky, atmosphere, or depth-of-field.

## Never
- No second subject, scale figure, crowd, or background props.
- No text, UI, frames, borders, labels, watermarks or logos.
- No thin floating parts, loose chains, wisps or trailing cloth — image->3D
  fuses or drops them.

## Finish
Even neutral light on every surface. Matte. Emissive details may glow but must
not light the background.
