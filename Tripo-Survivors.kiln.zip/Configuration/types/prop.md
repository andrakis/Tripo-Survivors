This subject is a static arena PROP — an inert obstacle or pickup, rendered as an
isolated game-ready asset. It has no face, no limbs, and no faction identity.

A single object, whole in frame. It sits on flat ground in-game, so model it flat
and stable at the bottom. No base, no plinth, no scene.
