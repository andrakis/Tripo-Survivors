This subject is the PLAYER character — one full-body hero figure, rendered as an
isolated game-ready asset. It is the single brightest, most readable thing in the
game and must stay legible at roughly the size of a thumbnail.

Full body, standing level on both feet, neutral pose. No base, no ground.
