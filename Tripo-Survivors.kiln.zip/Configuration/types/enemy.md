This subject is a single game ENEMY — one full-body creature, rendered as an
isolated game-ready asset. It must read as ONE silhouette when it is small on
screen among hundreds of others.

Compact, solid mass with a clear outline. Full body from head to feet, standing
level on both feet, nothing cropped. No base, no plinth, no ground.
