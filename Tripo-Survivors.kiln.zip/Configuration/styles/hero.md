# Hero Style

The player. One warm, bright figure against a dark arena and a cast of cool,
hostile shapes — the eye must find them instantly, always.

## Traits
- Warm pale gold as the dominant colour, high value, clearly the brightest thing
  in any frame it appears in.
- Compact, upright, athletic build with a confident level stance. Human
  proportions, very slightly heroic.
- Simple close-fitting kit: a fitted tunic or light harness, boots, gloves. Clean
  unbroken outline with nothing dangling.
- Readable from directly above as well as from the side — the camera looks down
  at about 45 degrees.

## Never
No cape, no cloak, no long hair, no loose straps or belts — they fuse to the body
in reconstruction. No cool or dark colours anywhere on the figure. No weapon: all
attacks in this game are auras and projectiles, never held arms.
