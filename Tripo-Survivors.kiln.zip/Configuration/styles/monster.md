# Monster Family Style

Every enemy tier belongs to one creature family, so a crowd of mixed tiers reads
as one army rather than a bag of unrelated models. Render this figure in that
family look.

## Shared traits
- Hard-edged, faceted, slightly angular anatomy — carved rather than grown.
- Heavy head and hands relative to the body; short neck; low forward lean.
- Dark, matte, faintly stone-like hide with the tier's hue as the dominant
  surface colour and a darker version of that same hue in the recesses.
- One bright accent — eyes or a chest core — glowing in the tier hue, the only
  emissive on the figure.
- Bare, simple limbs. No armour plates, no straps, no dangling kit.

## Distinction between tiers
Tiers differ by PROPORTION and BULK only — never by adding detail. A bigger tier
is a heavier, denser version of the same creature, not a more ornate one.

## Never
Never render fur, feathers, cloth, capes, or weapons. Never add a second colour
hue; the tier owns exactly one.
