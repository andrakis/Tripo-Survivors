# TRIPO SURVIVORS — Style Guideline

Concept art for a Survivors-like where a few hundred enemies converge on one
figure. Each image is a reference for a Tripo image->3D generation that ends up
as a single instanced mesh in-game.

## The look
- Chunky and bold. Big simple masses, one clean unbroken outline.
- Detail carried in COLOUR and SHAPE, never in fussy geometry — a ~1500-triangle
  mesh has to honour whatever is drawn.
- Matte and flat-lit. No PBR gloss, no photoreal skin, no grime spatter.

## Silhouette is the whole job
The player reads a threat as a shape 1.4-4.5 units tall in a dim arena, often
with fifty others on screen. Tier is read from OUTLINE first and colour second.
If two enemies share an outline, both are wrong.

## Palette
The arena is dark desaturated blue-grey and carries no chroma. The cast carries
all of it: each tier owns one saturated hue and nothing else uses that hue.

## Never
No environment, no scene, no plinth or base, no weapon effects, no gore.
