# Runner

## Prompt
The fast enemy — fragile, quicker than the player, and it arrives alone and
early. A tall, lean, narrow biped roughly 1.5 units tall: elongated wedge-shaped
torso, long thin legs built for sprinting, small pointed head thrust forward,
almost no bulk anywhere.

Dominant hue: saturated CYAN. Glowing cyan eyes as the only emissive.

Silhouette job: read as THIN AND TALL against the grunt's box — the player has to
identify it instantly, because it is the one enemy they cannot outrun.

Single figure, full body centred, neutral standing pose, legs slightly apart and
arms clear of the torso.

## Styles
* style-guideline.md
* monster.md

## Type: enemy.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
