# Elite

## Prompt
The rare hazard — a towering enemy the player routes around rather than fights.
A colossal biped roughly 4.5 units tall, nearly three times the height of a
grunt: long heavy limbs, a deep angular torso, a high crested head, standing tall
and upright rather than hunched like the smaller tiers.

Dominant hue: saturated VIOLET. Glowing violet eyes and a violet core seam as the
only emissive.

Silhouette job: read as ENORMOUS AND UPRIGHT. Convey the scale through
proportion — heavier limbs, denser mass — never by putting anything beside it.

Single figure, full body centred, tall neutral stance, arms clear of the body.

## Styles
* style-guideline.md
* monster.md

## Type: enemy.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
