# Grunt

## Prompt
The rank-and-file enemy — the mass of the swarm, seen in the hundreds. A small,
squat, blocky biped roughly 1.4 units tall: broad boxy torso, stubby thick limbs,
a heavy square head sunk low between the shoulders, no neck. Simple and
unmistakable at a glance, because most of the screen will be these.

Dominant hue: saturated GREEN. Glowing green eyes as the only emissive.

Silhouette job: read as SMALL AND BLOCKY — the baseline every other tier is
compared against.

Single figure, full body centred, neutral standing pose, arms clear of the body.

## Styles
* style-guideline.md
* monster.md

## Type: enemy.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
