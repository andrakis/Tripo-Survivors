# Brute

## Prompt
The heavy enemy — slow, and carries enough mass to survive long enough to reach
the player. A wide, thick, planted biped roughly 2.6 units tall and very broad:
enormous slab shoulders, deep barrel chest, short tree-trunk legs, massive heavy
forearms hanging low, tiny head buried between the shoulders.

Dominant hue: saturated RED. Glowing red chest core as the only emissive.

Silhouette job: read as WIDE — width is the tell, more than height. It should
look immovable next to a grunt.

Single figure, full body centred, planted stance, arms hanging clear of the
torso.

## Styles
* style-guideline.md
* monster.md

## Type: enemy.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
