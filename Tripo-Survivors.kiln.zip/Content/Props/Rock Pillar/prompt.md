# Rock Pillar

## Prompt
An arena obstacle — a standing rock pillar the swarm has to path around. A
single tall angular column of dark stone, roughly 4 units wide and 8 tall,
faceted and chunky, wider at the base and tapering slightly, weathered but not
crumbling.

Neutral desaturated grey-blue. No chroma at all — props are stage, not cast, and
must never compete with an enemy for attention.

Flat and stable at the bottom so it sits flush on flat ground.

Single object centred in frame, three-quarter view, nothing cropped.

## Styles
* style-guideline.md

## Type: prop.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
