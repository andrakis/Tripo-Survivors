# XP Orb

## Prompt
The XP pickup dropped where an enemy dies. A small faceted crystal shard roughly
0.45 units tall — a simple angular gem form, chunky and low-facet, glowing softly
from within.

Pale luminous blue, emissive, bright enough to read against dark ground even when
a hundred are scattered across the arena — but small enough that a pile of them
never hides the enemies standing on top.

Single object centred in frame, three-quarter view, no base, no ground.

## Styles
* style-guideline.md

## Type: prop.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 1:1
* Resolution: 1K
