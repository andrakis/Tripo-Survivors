# Survivor

## Prompt
The player character — one lone figure the whole swarm is walking toward. A
compact, athletic human roughly 1.7 units tall in simple close-fitting kit: a
fitted tunic or light harness, boots, gloves, short practical hair. Calm, alert,
upright, unarmed.

Warm pale gold, high value — the brightest thing in the game.

Silhouette job: read clearly from a camera looking down at 45 degrees, and stay
legible at thumbnail size surrounded by enemies.

Single figure, full body centred, neutral standing pose facing the viewer, arms
relaxed and clear of the torso.

## Styles
* style-guideline.md
* hero.md

## Type: hero.md

## Enforce output spec: yes

## Configuration
* Aspect ratio: 3:4
* Resolution: 1K
